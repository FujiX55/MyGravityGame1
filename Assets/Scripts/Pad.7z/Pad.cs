﻿using UnityEngine;
using System.Collections;

public class Pad {

	static Vector2 touchStart_;

	/// 入力方向を取得する.
	public static Vector2 GetInputVector() {
		float x = Input.GetAxisRaw("Horizontal");
		float y = Input.GetAxisRaw("Vertical");
		return new Vector2(x, y).normalized;
	}
	
	/// PUSHを検出する
	public static bool GetInputPush() {
		bool push = false;
		
		// スペースキー押下を検出
		push = Input.GetKeyDown(KeyCode.Space);
		
		// タッチを検出
		foreach (var touch in Input.touches) {
			if (touch.phase == TouchPhase.Began) {
				Debug.Log( "touch" );
				push = true;

				touchStart_ = touch.position;
			}
		}
		// 左クリックを検出
		if ( Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0) ) {
			push = true;
		}
		return push;
	}

	public static void Update()
	{

	}
}
